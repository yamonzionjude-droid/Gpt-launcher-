# GPT Launcher V1

Phone-buildable Android launcher UI.

## Build with AndroidIDE / AIDE
1. Extract the project folder.
2. Open the folder as an Android/Gradle project.
3. Let Gradle sync.
4. Build the debug APK.
5. Install the generated APK.

Package: `com.gptlauncher.minecraft`

This V1 provides the launcher UI and account-selection framework. It does NOT contain the Minecraft Java runtime or real Microsoft/Ely.by authentication yet. Those require the corresponding launcher/runtime integration and authentication implementations.
