package com.gptlauncher.minecraft;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    SharedPreferences prefs;

    int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    TextView text(String value, float size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(Color.rgb(20,20,20));
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.rgb(25,25,25));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(52));
        p.setMargins(0, dp(7), 0, dp(7));
        b.setLayoutParams(p);
        return b;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("gpt_launcher", MODE_PRIVATE);
        showHome();
    }

    void base() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(18), dp(20), dp(18));
        root.setBackgroundColor(Color.WHITE);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("◉", 30, true);
        bar.addView(logo, new LinearLayout.LayoutParams(dp(48), dp(52)));
        TextView title = text("GPT Launcher", 22, true);
        bar.addView(title, new LinearLayout.LayoutParams(0, dp(52), 1));
        TextView menu = text("⋮", 30, false);
        menu.setGravity(Gravity.CENTER);
        bar.addView(menu, new LinearLayout.LayoutParams(dp(42), dp(52)));
        root.addView(bar);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(18), 0, dp(20));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    void showHome() {
        base();
        content.addView(text("Java Edition Launcher", 28, true),
                new LinearLayout.LayoutParams(-1, dp(55)));
        content.addView(text("Choose an account to continue.", 16, false),
                new LinearLayout.LayoutParams(-1, dp(42)));

        String saved = prefs.getString("account", "No account selected");
        TextView account = text("Account: " + saved, 15, false);
        account.setPadding(dp(14),0,dp(14),0);
        account.setBackgroundColor(Color.rgb(245,245,245));
        content.addView(account, new LinearLayout.LayoutParams(-1, dp(52)));

        Button login = button("Select account");
        login.setOnClickListener(v -> showAccounts());
        content.addView(login);

        content.addView(text("Minecraft version", 17, true),
                new LinearLayout.LayoutParams(-1, dp(48)));
        Spinner versions = new Spinner(this);
        String[] list = {"Select version", "1.21.x", "1.20.x", "1.19.x", "Custom"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item, list);
        versions.setAdapter(adapter);
        content.addView(versions, new LinearLayout.LayoutParams(-1, dp(52)));

        Button launch = button("Launch Minecraft");
        launch.setOnClickListener(v -> Toast.makeText(this,
                "V1 UI ready. Minecraft engine integration comes next.",
                Toast.LENGTH_LONG).show());
        content.addView(launch);

        TextView note = text("GPT Launcher V1 • Android", 13, false);
        note.setGravity(Gravity.CENTER);
        content.addView(note, new LinearLayout.LayoutParams(-1, dp(60)));
    }

    void showAccounts() {
        base();
        content.addView(text("Choose account", 28, true),
                new LinearLayout.LayoutParams(-1, dp(60)));
        content.addView(text("Select how GPT Launcher should sign in.", 15, false),
                new LinearLayout.LayoutParams(-1, dp(42)));

        Button microsoft = button("Microsoft");
        microsoft.setOnClickListener(v -> select("Microsoft"));
        content.addView(microsoft);

        Button ely = button("Ely.by");
        ely.setOnClickListener(v -> select("Ely.by"));
        content.addView(ely);

        Button offline = button("Offline");
        offline.setOnClickListener(v -> showOffline());
        content.addView(offline);

        Button back = button("Back");
        back.setOnClickListener(v -> showHome());
        content.addView(back);
    }

    void select(String type) {
        prefs.edit().putString("account", type).apply();
        new AlertDialog(this).show(type + " account",
                "Authentication integration is reserved for the launcher engine. "
                + "This V1 records the selected account type without asking for passwords.");
        showHome();
    }

    void showOffline() {
        base();
        content.addView(text("Offline account", 28, true),
                new LinearLayout.LayoutParams(-1, dp(60)));
        EditText name = new EditText(this);
        name.setHint("Minecraft username");
        name.setSingleLine(true);
        content.addView(name, new LinearLayout.LayoutParams(-1, dp(58)));

        Button save = button("Use offline account");
        save.setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            if (n.length() < 1) {
                name.setError("Enter a username");
                return;
            }
            prefs.edit().putString("account", "Offline • " + n).apply();
            showHome();
        });
        content.addView(save);

        Button back = button("Back");
        back.setOnClickListener(v -> showAccounts());
        content.addView(back);
    }

    class AlertDialog {
        Activity a;
        AlertDialog(Activity x){a=x;}
        void show(String title, String msg) {
            new android.app.AlertDialog.Builder(a)
                    .setTitle(title).setMessage(msg)
                    .setPositiveButton("OK", null).show();
        }
    }
}
